
public class Function3 extends Function {
	public String toString() {
		return "Closest point on P to point Q(0, 1)";
	}
	
	public String answerString(double optVal, double x, double y, double z) {
		return "Asnwer: (" + x + ", " + y + ")";
	}
	
	public double fnValue(double x) {
		return Math.sqrt(Math.pow(x, 4) - Math.pow(x, 2) + 1);
	}
	
	public double getXVal(double x) {
		return x;
	}
	
	public double getYVal(double x) {
		return Math.pow(x, 2);
	}
	
	public double getZVal(double x) {
		return -1;
	}
}
