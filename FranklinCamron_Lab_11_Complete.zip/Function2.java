
public class Function2 extends Function {
	public String toString() {
		return "Minimize the time the dog has to run/swim";
	}
	
	public double getXVal(double x) {
		return x;
	}
	
	public String answerString(double optVal, double x, double y, double z) {
		return "Answer (seconds): " + optVal + ", dog to shore (m): " + x + ", shore to ball (m): " + y;
	}
	
	public double fnValue(double x) {
		return (x/3 + (2 * Math.sqrt(Math.pow(x, 2) - (8 * x) + 25)));
	}

	
	public double getYVal(double x) {
		return Math.sqrt(Math.pow(3, 2) + Math.pow(4 - x, 2));
	}
	
	public double getZVal(double x) {
		return  -1;
	}
}
