
public class Function1 extends Function {
	
	public String toString() {
		return "Minimize the cost of a can that will hold two liters of liquid";
	}
	
	public String answerString(double optVal, double x, double y, double z) {
		return "Answer: " + optVal  + ", radius (cm):" + x + ", height (cm):" + y;
	}
	
	public double fnValue(double x) {
		return ((0.8 * Math.PI * Math.pow(x, 2)) + 800 / x);
	}
	
	public double getXVal(double x) {
		return x;
	}
	
	public double getYVal(double x) {
		return (2000 / (Math.PI * Math.pow(x, 2)));
	}
	
	public double getZVal(double x) {
		return -1;
	}
}
